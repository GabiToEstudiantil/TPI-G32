package ar.edu.utn.frc.bda.k7.geoapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GeoapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(GeoapiApplication.class, args);
	}

}
