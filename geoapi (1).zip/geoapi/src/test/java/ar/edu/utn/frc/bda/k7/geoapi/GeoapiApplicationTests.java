package ar.edu.utn.frc.bda.k7.geoapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GeoapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
